# Welcome to PyTCT
The TCT software package is designed for the synthesis of supervisory controls for untimed discrete-event systems (DES).   
PyTCT provides Python Binding of the TCT so that TCT can be used from Python.


Next: [Getting started](./basic_sample.md)